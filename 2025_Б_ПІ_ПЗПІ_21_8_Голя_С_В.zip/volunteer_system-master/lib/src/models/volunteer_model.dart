class Volunteer {
  final String id;
  final String name;
  final String surname;
  final String email;
  final String phone;
  final String? picture;
  final int? age;
  final String? specific;
  final String? bio;
  final bool? available;
  final String? userAccountId;

  Volunteer({
    required this.id,
    required this.name,
    required this.surname,
    required this.email,
    required this.phone,
    this.picture,
    this.age,
    this.bio,
    this.specific,
    this.available,
    this.userAccountId,
  });
  Volunteer copyWith({
    String? id,
    String? name,
    String? surname,
    String? email,
    String? phone,
    String? picture,
    int? age,
    String? specific,
    bool? available,
    String? userAccountId,
  }) {
    return Volunteer(
      id: id ?? this.id,
      name: name ?? this.name,
      surname: surname ?? this.surname,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      picture: picture ?? this.picture,
      age: age ?? this.age,
      specific: specific ?? this.specific,
      available: available ?? this.available,
      userAccountId: userAccountId ?? this.userAccountId,
    );
  }

  factory Volunteer.fromJson(Map<String, dynamic> json) => Volunteer(
        id: json['id'] ?? '',
        name: json['name'] ?? '',
        surname: json['surname'] ?? '',
        email: json['email'] ?? '',
        phone: json['phone'] ?? '',
        picture: json['profile_pic'],
        age: json['age'] != null ? int.tryParse(json['age'].toString()) : null,
        specific: json['specific'],
        available: json['available'],
        bio: json['bio'],
        userAccountId: json['user_account_id'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'surname': surname,
        'email': email,
        'phone': phone,
        'profile_pic': picture,
        'age': age,
        'bio': bio,
        'specific': specific,
        'available': available,
        'user_account_id': userAccountId,
      };
  Map<String, dynamic> toPartialJson() => {
        'email': email,
        'phone': phone,
        'name': name,
        'surname': surname,
        'age': age?.toString(),
        'available': available,
        'bio': bio,
        'profile_pic': picture,
      };
}

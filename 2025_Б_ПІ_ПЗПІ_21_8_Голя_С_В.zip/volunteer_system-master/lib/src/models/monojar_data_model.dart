class MonoJarData {
  final int amount;
  final int goal;

  MonoJarData({required this.amount, required this.goal});

  double get progressPercent {
    if (goal == 0) return 0.0;
    return (amount / goal) * 100;
  }
}

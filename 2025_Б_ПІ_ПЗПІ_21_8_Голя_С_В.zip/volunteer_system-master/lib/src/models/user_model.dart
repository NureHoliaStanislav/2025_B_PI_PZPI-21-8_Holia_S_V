class User {
  final String id;
  final String email;
  final String? bio;
  final String role;
  final String? lastLogin;
  final String? profilePic;

  User({
    required this.id,
    required this.email,
    this.bio,
    required this.role,
    this.lastLogin,
    this.profilePic,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      email: json['email'],
      bio: json['bio'],
      role: json['role'],
      lastLogin: json['last_login'],
      profilePic: json['profile_pic'],
    );
  }
}

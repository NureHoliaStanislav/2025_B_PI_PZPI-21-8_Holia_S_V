class Item {
  final String? id;
  final String name;
  final int count;
  final String category;
  final String? reservedBy;

  Item({
    this.id,
    required this.name,
    required this.count,
    required this.category,
    this.reservedBy,
  });

  factory Item.fromJson(Map<String, dynamic> json) => Item(
        id: json['id'],
        name: json['name'],
        count: json['count'],
        category: json['category'],
        reservedBy: json['reserved_by'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'count': count,
        'category': category,
        if (reservedBy != null) 'reserved_by': reservedBy,
      };
}

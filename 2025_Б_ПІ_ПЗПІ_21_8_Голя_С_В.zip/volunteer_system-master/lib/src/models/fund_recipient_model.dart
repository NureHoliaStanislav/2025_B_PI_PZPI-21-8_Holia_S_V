class FundRecipient {
  final String fundId;
  final String recipientId;
  final DateTime deliveredAt;

  FundRecipient({
    required this.fundId,
    required this.recipientId,
    required this.deliveredAt,
  });

  factory FundRecipient.fromJson(Map<String, dynamic> json) => FundRecipient(
        fundId: json['fund_id'],
        recipientId: json['recipient_id'],
        deliveredAt: DateTime.parse(json['delivered_at']),
      );
}

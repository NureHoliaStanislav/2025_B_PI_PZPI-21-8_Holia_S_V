import 'package:volunteer_system/src/models/item_model.dart';
import 'package:volunteer_system/src/models/recepient_model.dart';

enum Priority {
  High,
  Default,
}

class Requirement {
  final String id;
  final DateTime? deadline;
  final String name;
  final Priority priority;
  final String description;
  final Recipient recipient;
  final String? picture;
  final List<Item> items;
  final List<Map<String, dynamic>> fund; // To store fund data as raw map

  Requirement({
    required this.id,
    this.deadline,
    required this.name,
    required this.priority,
    required this.description,
    required this.recipient,
    this.picture,
    required this.items,
    this.fund = const [], // Default empty fund list
  });

  factory Requirement.fromJson(Map<String, dynamic> json) => Requirement(
        id: json['id'],
        deadline:
            json['deadline'] != null ? DateTime.parse(json['deadline']) : null,
        name: json['name'],
        priority: Priority.values
            .firstWhere((e) => e.toString() == 'Priority.${json['priority']}'),
        description: json['description'],
        picture: json['picture'],
        items:
            (json['items'] as List).map((item) => Item.fromJson(item)).toList(),
        recipient: Recipient.fromJson(json['recipient']),
        fund: json['fund'] != null
            ? List<Map<String, dynamic>>.from(json['fund'])
            : [],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'deadline': deadline?.toIso8601String(),
        'name': name,
        'priority': priority.name,
        'description': description,
        if (picture != null) 'picture': picture,
        'items': items.map((e) => e.toJson()).toList(),
        'recipient': recipient.toJson(),
        'fund': fund, // Include fund data as is
      };
}

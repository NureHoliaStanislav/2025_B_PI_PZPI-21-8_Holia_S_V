class Recipient {
  final String id;
  final String name;
  final String email;
  final String? userAccountId;
  final String? profilePic;

  Recipient({
    required this.id,
    required this.name,
    required this.email,
    this.userAccountId,
    this.profilePic,
  });

  factory Recipient.fromJson(Map<String, dynamic> json) => Recipient(
        id: json['id'],
        name: json['name'],
        email: json['email'],
        userAccountId: json['user_account_id'],
        profilePic: json['profile_pic'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'email': email,
        if (userAccountId != null) 'user_account_id': userAccountId,
        if (profilePic != null) 'profile_pic': profilePic,
      };
}

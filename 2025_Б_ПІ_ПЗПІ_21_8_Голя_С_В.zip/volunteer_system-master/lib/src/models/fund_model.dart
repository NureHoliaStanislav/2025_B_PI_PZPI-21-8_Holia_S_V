import 'package:volunteer_system/src/models/report_model.dart';
import 'package:volunteer_system/src/models/requirement_model.dart';
import 'package:volunteer_system/src/models/volunteer_model.dart';

class Fund {
  final String id;
  final String name;
  final String? description;
  final String monoJarUrl;
  final String longJarId;
  final String status;
  final String? picture;
  final Report? report;
  final Volunteer volunteer;
  final Requirement requirement;

  Fund({
    required this.id,
    required this.name,
    this.description,
    required this.monoJarUrl,
    required this.longJarId,
    required this.status,
    this.picture,
    this.report,
    required this.volunteer,
    required this.requirement,
  });

  factory Fund.fromJson(Map<String, dynamic> json) => Fund(
        id: json['id'],
        name: json['name'],
        description: json['description'],
        monoJarUrl: json['mono_jar_url'],
        longJarId: json['long_jar_id'],
        status: json['status'],
        picture: json['picture'],
        report: json['report'] != null ? Report.fromJson(json['report']) : null,
        volunteer: Volunteer.fromJson(json['volunteer']),
        requirement: Requirement.fromJson(json['requirement']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'mono_jar_url': monoJarUrl,
        'long_jar_id': longJarId,
        'status': status,
        'picture': picture,
        if (report != null) 'report': report!.toJson(),
        'volunteer': volunteer.toJson(),
        'requirement': requirement.toJson(),
      };
}

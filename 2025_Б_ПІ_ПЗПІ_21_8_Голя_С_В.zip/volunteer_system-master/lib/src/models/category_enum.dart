enum CategoryEnum {
  food("Food"),
  medicine("Medicine"),
  militaryEquipment("Military Equipment"),
  tacticalGear("Tactical Gear"),
  clothing("Clothing"),
  hygiene("Hygiene"),
  electronicsAndOptics("Electronics and Optics"),
  powerSupply("Power Supply"),
  vehicles("Vehicles"),
  fuel("Fuel"),
  construction("Construction"),
  communications("Communications"),
  tools("Tools"),
  drones("Drones"),
  winterEquipment("Winter Equipment"),
  animalSupport("Animal Support"),
  other("Other");

  final String value;
  const CategoryEnum(this.value);

  @override
  String toString() => value;
}

class Report {
  final String id;
  final int rating;
  final String finalConclusion;

  Report({
    required this.id,
    required this.rating,
    required this.finalConclusion,
  });

  factory Report.fromJson(Map<String, dynamic> json) => Report(
        id: json['id'],
        rating: json['rating'],
        finalConclusion: json['final_conclution'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'rating': rating,
        'final_conclution': finalConclusion,
      };
}

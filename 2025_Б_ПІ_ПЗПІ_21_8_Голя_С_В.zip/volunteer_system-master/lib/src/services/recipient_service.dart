import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:volunteer_system/src/utils/api_config.dart';
import 'package:volunteer_system/src/models/recepient_model.dart';
import 'package:volunteer_system/src/models/requirement_model.dart';
import 'package:volunteer_system/src/services/auth_service.dart';

class RecipientService {
  static Future<Recipient?> getRecipientProfile() async {
    final token = await AuthService.getToken();

    if (token == null || token.isEmpty) {
      throw Exception('No token found in SharedPreferences');
    }

    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/recipient/profile'),
        headers: {
          'accept': 'application/json',
          'token': token,
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(utf8.decode(response.bodyBytes));
        return Recipient.fromJson(data);
      } else {
        throw Exception('Не вдалося завантажити профіль отримувача');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<List<Requirement>> getRecipientRequirements(
      String recipientId) async {
    final response = await http.get(
      Uri.parse('${ApiConfig.baseUrl}/recipient/$recipientId/requirements'),
      headers: {
        'accept': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(utf8.decode(response.bodyBytes));
      return data.map((json) => Requirement.fromJson(json)).toList();
    } else {
      throw Exception('Не вдалося завантажити вимоги отримувача');
    }
  }
}

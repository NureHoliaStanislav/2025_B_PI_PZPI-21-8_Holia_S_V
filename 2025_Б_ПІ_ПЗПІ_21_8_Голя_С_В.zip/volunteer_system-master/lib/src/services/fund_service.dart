import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:volunteer_system/src/utils/api_config.dart';
import 'package:volunteer_system/src/models/fund_model.dart';
import 'package:volunteer_system/src/services/auth_service.dart';
import 'package:http_parser/http_parser.dart';

class FundService {
  static Future<Fund?> fetchFundDetail(String fundId) async {
    final response = await http.get(
      Uri.parse('${ApiConfig.baseUrl}/fund/$fundId'),
      headers: {'accept': 'application/json'},
    );

    if (response.statusCode == 200) {
      final decoded = utf8.decode(response.bodyBytes);
      final json = jsonDecode(decoded);
      return Fund.fromJson(json);
    } else {
      return null;
    }
  }

  static Future<String?> createFund(Map<String, dynamic> fundJson) async {
    final token = await AuthService.getToken();
    if (token == null) return null;

    final uri = Uri.parse('${ApiConfig.baseUrl}/fund/');
    final response = await http.post(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'accept': 'application/json',
        'token': token,
      },
      body: jsonEncode(fundJson),
    );

    if (response.statusCode == 200) {
      final decoded = utf8.decode(response.bodyBytes);
      final json = jsonDecode(decoded);
      return json['id']; // <-- очікується, що бек повертає fund_id
    }

    return null;
  }

  static Future<String?> uploadFundImage(String fundId, File imageFile) async {
    final uri = Uri.parse('${ApiConfig.baseUrl}/fund/photo?fund_id=$fundId');
    final request = http.MultipartRequest('POST', uri);

    final token = await AuthService.getToken();
    if (token == null) return null;

    request.headers['token'] = token;

    request.files.add(await http.MultipartFile.fromPath(
      'fund_photo', // має відповідати назві параметру в FastAPI
      imageFile.path,
    ));

    final response = await request.send();

    if (response.statusCode == 200) {
      final responseBody = await response.stream.bytesToString();
      final json = jsonDecode(responseBody);

      final String? profilePic = json['profile_pic'];
      if (profilePic != null && profilePic.isNotEmpty) {
        return profilePic;
      }
    }

    return null;
  }

  static Future<bool> updateFund({
    required String fundId,
    required String name,
    required String description,
  }) async {
    final token = await AuthService.getToken();
    if (token == null) return false;

    final uri = Uri.parse('${ApiConfig.baseUrl}/fund/$fundId');

    final response = await http.put(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'accept': 'application/json',
        'token': token,
      },
      body: jsonEncode({
        'name': name,
        'description': description,
      }),
    );

    return response.statusCode == 200;
  }

  static Future<bool> deactivateFund(String fundId) async {
    final token = await AuthService.getToken();
    if (token == null) return false;

    final uri = Uri.parse('${ApiConfig.baseUrl}/fund/$fundId');
    final response = await http.put(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'accept': 'application/json',
        'token': token,
      },
      body: jsonEncode({
        'status': 'Completed',
      }),
    );

    return response.statusCode == 200;
  }

  static Future<bool> uploadReportPdf(
    String fundId,
    List<int> bytes,
    String filename,
  ) async {
    final uri = Uri.parse('${ApiConfig.baseUrl}/fund/$fundId/report/pdf');

    final token =
        await AuthService.getToken(); // Або твій спосіб отримання токена

    final request = http.MultipartRequest('POST', uri)
      ..headers['token'] = token ?? ''
      ..files.add(http.MultipartFile.fromBytes(
        'report_pdf',
        bytes,
        filename: filename,
        contentType: MediaType('application', 'pdf'),
      ));

    final response = await request.send();

    if (response.statusCode == 200) {
      return true;
    } else {
      final body = await response.stream.bytesToString();
      debugPrint('uploadReportPdf error: ${response.statusCode} - $body');
      return false;
    }
  }

  static Future<bool> leaveFundReport({
    required String fundId,
    required int rating,
    required String finalConclusion,
  }) async {
    final token = await AuthService.getToken();
    if (token == null) return false;

    final uri = Uri.parse('${ApiConfig.baseUrl}/fund/$fundId/report');
    final response = await http.post(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'accept': 'application/json',
        'token': token,
      },
      body: jsonEncode({
        'rating': rating,
        'final_conclution': finalConclusion,
      }),
    );

    return response.statusCode == 200;
  }
}

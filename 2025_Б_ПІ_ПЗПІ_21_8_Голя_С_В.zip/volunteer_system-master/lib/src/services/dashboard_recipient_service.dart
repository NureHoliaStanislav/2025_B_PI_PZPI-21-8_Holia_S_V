import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:http/http.dart' as http;
import 'package:volunteer_system/src/utils/api_config.dart';
import 'package:volunteer_system/src/services/auth_service.dart';

class DashboardRecipientService {
  static Future<Map<String, dynamic>> fetchDashboardData(
      BuildContext context) async {
    final token = await AuthService.getToken();

    if (token == null || token.isEmpty) {
      throw Exception('No token found in SharedPreferences');
    }

    final uri = Uri.parse('${ApiConfig.baseUrl}/recipient/dashboard');

    final response = await http.get(
      uri,
      headers: {
        'token': token,
        'accept': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      return json.decode(utf8.decode(response.bodyBytes))
          as Map<String, dynamic>;
    } else if (response.statusCode == 401) {
      AuthService.logout();
      context.go('/login');
      throw Exception('Unauthorized – redirected to login');
    } else {
      print('Status: ${response.statusCode}');
      print('Body: ${utf8.decode(response.bodyBytes)}');
      throw Exception('Failed to fetch dashboard data');
    }
  }
}

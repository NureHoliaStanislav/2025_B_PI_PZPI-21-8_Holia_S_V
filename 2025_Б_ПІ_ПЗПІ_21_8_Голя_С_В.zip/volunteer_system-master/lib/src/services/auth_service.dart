import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:volunteer_system/src/utils/api_config.dart';
import '../models/token_model.dart';

class AuthService {
  static Future<(Token, String)?> login(String email, String password) async {
    try {
      print('AuthService.login called with $email / $password');
      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/profile/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'password': password}),
      );

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);

        final accessToken = jsonData['access_token'];
        final role = jsonData['role'] as String;
        final userId = jsonData['user']['id'] as String?;

        if (accessToken != null && userId != null) {
          final token = Token(accessToken: accessToken, tokenType: "Bearer");

          await _saveToken(token.accessToken);
          await _saveRole(role);
          await _saveUserId(userId);

          return (token, role);
        }
      } else {
        print('Login failed with status ${response.statusCode}');
      }

      return null;
    } catch (e) {
      print('Error in AuthService.login: $e');
      return null;
    }
  }

  static Future<void> _saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('access_token', token);
  }

  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('access_token');
  }

  static Future<void> _saveRole(String role) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_role', role);
  }

  static Future<String?> getRole() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('user_role');
  }

  static Future<void> _saveUserId(String userId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_id', userId);
  }

  static Future<String?> getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('user_id');
  }

  static Future<bool> isVolunteer() async {
    final role = await getRole();
    return role == 'Volunteer';
  }

  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('access_token');
    await prefs.remove('user_role');
    await prefs.remove('user_id');
  }
}

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:volunteer_system/src/utils/api_config.dart';
import 'package:volunteer_system/src/models/item_model.dart';
import 'package:volunteer_system/src/models/requirement_model.dart';

class RequirementService {
  // Function to fetch the requirement data
  Future<Requirement> getRequirement(String requirementId) async {
    final response = await http.get(
      Uri.parse('${ApiConfig.baseUrl}/requirement/$requirementId'),
      headers: {'Accept': 'application/json'},
    );

    if (response.statusCode == 200) {
      final decoded = utf8.decode(response.bodyBytes);
      final jsonData = json.decode(decoded);
      // Parse the requirement model and the fund separately
      Requirement requirement = Requirement.fromJson(jsonData);
      return requirement;
    } else {
      throw Exception('Failed to load requirement');
    }
  }

  static Future<String> createRequirement({
    required String name,
    required String description,
    required String priority,
    required DateTime? deadline,
    required String token,
  }) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/requirement/'),
      headers: {
        'Content-Type': 'application/json',
        'accept': 'application/json',
        'token': token,
      },
      body: json.encode({
        'name': name,
        'description': description,
        'priority': priority,
        'deadline':
            deadline?.toIso8601String().split('T').first, // "YYYY-MM-DD"
      }),
    );

    if (response.statusCode == 200 || response.statusCode == 201) {
      final jsonResponse = json.decode(response.body);
      final requirementId = jsonResponse['id'];

      return requirementId;
    } else {
      throw Exception('Не вдалося створити вимогу');
    }
  }

  static Future<void> addItemsToRequirement({
    required String token,
    required String requirementId,
    required List<Item> items,
  }) async {
    final url =
        Uri.parse('${ApiConfig.baseUrl}/requirement/$requirementId/items');

    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode(items.map((item) => item.toJson()).toList()),
    );

    if (response.statusCode != 200 && response.statusCode != 201) {
      throw Exception('Failed to add items: ${response.body}');
    }
  }
}

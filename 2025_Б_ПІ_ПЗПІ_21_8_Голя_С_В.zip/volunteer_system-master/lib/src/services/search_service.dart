// lib/src/services/search_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:volunteer_system/src/utils/api_config.dart';

class SearchService {
  static Future<List<dynamic>> searchFunds(String query) async {
    final uri = Uri.parse('${ApiConfig.baseUrl}/fund?query=$query');

    final response = await http.get(uri);

    if (response.statusCode == 200) {
      final decoded = utf8.decode(response.bodyBytes);
      return jsonDecode(decoded) as List<dynamic>;
    } else {
      throw Exception('Помилка під час пошуку: ${response.statusCode}');
    }
  }

  static Future<List<dynamic>> searchRequirements(String query) async {
    final uri = Uri.parse('${ApiConfig.baseUrl}/requirement/?query=$query');

    final response = await http.get(uri);

    if (response.statusCode == 200) {
      final decoded = utf8.decode(response.bodyBytes);
      return jsonDecode(decoded) as List<dynamic>;
    } else {
      throw Exception(
          'Помилка під час пошуку requirements: ${response.statusCode}');
    }
  }
}

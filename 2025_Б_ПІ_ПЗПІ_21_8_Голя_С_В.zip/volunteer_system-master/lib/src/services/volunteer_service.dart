import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:volunteer_system/src/models/fund_model.dart';
import 'package:volunteer_system/src/models/volunteer_model.dart';
import 'package:volunteer_system/src/services/auth_service.dart';
import 'package:volunteer_system/src/utils/api_config.dart';

class VolunteerService {
  static Future<Volunteer?> getVolunteerProfile() async {
    final token = await AuthService.getToken();

    if (token == null || token.isEmpty) {
      throw Exception('No token found in SharedPreferences');
    }

    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/volunteer/profile'),
        headers: {
          'accept': 'application/json',
          'token': token,
        },
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data =
            json.decode(utf8.decode(response.bodyBytes));
        // Витягуємо profile_pic окремо й додаємо до кореня
        final userAccount = data['user_account'];
        if (userAccount != null && userAccount['profile_pic'] != null) {
          data['profile_pic'] = userAccount['profile_pic'];
        }
        return Volunteer.fromJson(data);
      } else {
        throw Exception('Failed to load volunteer profile');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<Volunteer?> getVolunteerProfileById(String id) async {
    final token = await AuthService.getToken();

    if (token == null || token.isEmpty) {
      throw Exception('No token found in SharedPreferences');
    }

    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.baseUrl}/volunteer/profile?id=$id'),
        headers: {
          'accept': 'application/json',
          'token': token,
        },
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data =
            json.decode(utf8.decode(response.bodyBytes));
        final userAccount = data['user_account'];
        if (userAccount != null && userAccount['profile_pic'] != null) {
          data['profile_pic'] = userAccount['profile_pic'];
        }
        return Volunteer.fromJson(data);
      } else {
        throw Exception('Failed to load volunteer profile by ID');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<List<Fund>> fetchVolunteerFunds(String volunteerId) async {
    final token = await AuthService.getToken();
    if (token == null || token.isEmpty) {
      throw Exception('No token found in SharedPreferences');
    }
    final res = await http.get(
      Uri.parse('${ApiConfig.baseUrl}/volunteer/$volunteerId/funds'),
      headers: {
        'accept': 'application/json',
        'token': token,
      },
    );

    if (res.statusCode == 200) {
      final List data = json.decode(utf8.decode(res.bodyBytes));
      return data.map((json) => Fund.fromJson(json)).toList();
    } else {
      return [];
    }
  }

  static Future<void> updateProfile(Volunteer volunteer) async {
    final token = await AuthService.getToken();
    if (token == null || token.isEmpty) {
      throw Exception('No token found in SharedPreferences');
    }

    final response = await http.patch(
      Uri.parse('${ApiConfig.baseUrl}/volunteer/'),
      headers: {
        'Content-Type': 'application/json',
        'accept': 'application/json',
        'token': token, // заміни на реальну авторизацію
      },
      body: jsonEncode(volunteer.toPartialJson()),
    );

    if (response.statusCode != 200) {
      throw Exception('Помилка оновлення профілю');
    }
  }

  static Future<String?> uploadProfileImage(File file) async {
    final uri = Uri.parse("${ApiConfig.baseUrl}/profile/photo");
    final request = http.MultipartRequest('POST', uri);

    // Додаємо файл як "volunteer_photo"
    request.files.add(await http.MultipartFile.fromPath(
      'user_photo',
      file.path,
    ));

    // Додаємо заголовок з токеном
    final token = await AuthService.getToken();
    if (token == null) return null;
    request.headers['token'] = token;

    final response = await request.send();

    if (response.statusCode == 200) {
      final decoded = await response.stream.bytesToString();
      final json = jsonDecode(decoded);

      // Перевіряємо, чи є ключ profile_pic в json
      final String? profilePic = json['profile_pic'];

      // Якщо profile_pic не порожній рядок, повертаємо його
      if (profilePic != null && profilePic.isNotEmpty) {
        return profilePic;
      } else {
        return null; // або повертаємо деяке повідомлення, якщо потрібно
      }
    } else {
      return null; // можна додати логування помилки
    }
  }
}

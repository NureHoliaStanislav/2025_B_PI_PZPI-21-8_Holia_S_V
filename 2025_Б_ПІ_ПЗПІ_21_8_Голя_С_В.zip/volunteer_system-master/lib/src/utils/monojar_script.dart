import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:volunteer_system/src/models/monojar_data_model.dart';

Future<MonoJarData> getMonoJarData(String jarId) async {
  // Валідація довжини
  if (jarId.length != 32) {
    throw const FormatException(
        'Неправильна довжина MonoJar ID. Має бути 32 символи.');
  }

  // Валідація символів (тільки латинські літери та цифри)
  final regex = RegExp(r'^[a-zA-Z0-9]{32}$');
  if (!regex.hasMatch(jarId)) {
    throw const FormatException('MonoJar ID містить недопустимі символи.');
  }

  final url = 'https://api.monobank.ua/bank/jar/$jarId';

  final response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    final data = jsonDecode(response.body);
    final int amount = data['amount'];
    final int goal = data['goal'];
    return MonoJarData(amount: amount, goal: goal);
  } else {
    throw Exception('Не вдалося отримати дані з MonoJar');
  }
}

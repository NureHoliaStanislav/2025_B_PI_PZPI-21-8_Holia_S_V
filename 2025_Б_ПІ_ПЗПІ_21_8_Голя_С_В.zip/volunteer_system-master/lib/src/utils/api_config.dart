class ApiConfig {
  static const String baseUrl =
      'https://58b8-159-224-64-137.ngrok-free.app/api';
}

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:volunteer_system/src/services/auth_service.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _initializeAuth();
  }

  Future<void> _initializeAuth() async {
    final token = await AuthService.getToken();
    final role = await AuthService.getRole();

    if (!mounted) return;

    if (token != null) {
      switch (role) {
        case 'Volunteer':
          context.go('/dashboard');
          break;
        case 'Recipient':
          context.go('/dashboard');
          break;
        default:
          context.go('/login');
      }
    } else {
      context.go('/login');
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: CircularProgressIndicator()),
    );
  }
}

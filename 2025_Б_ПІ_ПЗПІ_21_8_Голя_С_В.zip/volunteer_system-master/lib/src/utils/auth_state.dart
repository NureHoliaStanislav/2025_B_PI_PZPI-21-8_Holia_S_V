import 'package:flutter/foundation.dart';
import 'package:volunteer_system/src/services/auth_service.dart';

class AuthState extends ChangeNotifier {
  String? _token;
  String? _role;
  String? _userId;

  String? get token => _token;
  String? get role => _role;
  String? get userId => _userId;
  bool _isInitialized = false;
  bool get isLoggedIn => _token != null;
  bool get isInitialized => _isInitialized;

  AuthState() {
    init(); // автоматичне завантаження
  }

  Future<void> init() async {
    _token = await AuthService.getToken();
    _role = await AuthService.getRole();
    _userId = await AuthService.getUserId();
    _isInitialized = true;
    notifyListeners();
  }

  Future<bool> login(String email, String password) async {
    final result = await AuthService.login(email, password);
    if (result != null) {
      final (token, role) = result;
      _token = token.accessToken;
      _role = role; // тепер точно має значення
      _isInitialized = true;
      notifyListeners();
      return true;
    }
    return false;
  }

  Future<void> logout() async {
    await AuthService.logout();
    _token = null;
    _role = null;
    notifyListeners();
  }
}

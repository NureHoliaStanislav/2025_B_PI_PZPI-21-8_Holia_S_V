import 'package:go_router/go_router.dart';
import 'package:volunteer_system/src/screens/dashboard_recipient_screen.dart';
import 'package:volunteer_system/src/screens/edit_volunteer_profile_screen.dart';
import 'package:volunteer_system/src/screens/login_screen.dart';
import 'package:volunteer_system/src/screens/dashboard_volunteer_screen.dart';
import 'package:volunteer_system/src/screens/recipient_profile_screen.dart';
import 'package:volunteer_system/src/screens/search.dart';
import 'package:volunteer_system/src/screens/volunteer_profile_screen.dart';
import 'package:volunteer_system/src/utils/splash_screen.dart';
import 'package:volunteer_system/src/common_widgets/main_scaffold.dart';
import 'package:volunteer_system/src/models/volunteer_model.dart';
import 'package:flutter/material.dart';
import 'package:volunteer_system/src/utils/auth_state.dart';

GoRouter createRouter(AuthState authState) {
  return GoRouter(
    initialLocation: '/splash',
    refreshListenable: authState,
    redirect: (context, state) {
      final loggedIn = authState.isLoggedIn;
      final goingToLogin = state.fullPath == '/login';
      final goingToSplash = state.fullPath == '/splash';

      if (!authState.isInitialized) return null; // show splash until ready

      if (!loggedIn) {
        return goingToLogin ? null : '/login';
      }

      if (goingToSplash || goingToLogin) return '/dashboard';

      return null;
    },
    routes: [
      GoRoute(
        path: '/splash',
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: '/login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: '/profile/edit',
        builder: (context, state) {
          final volunteer = state.extra as Volunteer;
          return EditProfileScreen(volunteer: volunteer);
        },
      ),
      ShellRoute(
        builder: (context, state, child) => MainScaffold(child: child),
        routes: [
          GoRoute(
            path: '/dashboard',
            builder: (context, state) {
              final role = authState.role;
              if (role == 'Volunteer') {
                return const DashboardVolunteerPage();
              } else if (role == 'Recipient') {
                return const DashboardRecipientPage();
              } else {
                return const Text('Unknown role');
              }
            },
          ),
          GoRoute(
            path: '/search',
            builder: (context, state) => const FundSearchPage(),
          ),
          GoRoute(
              path: '/profile',
              builder: (context, state) {
                final role = authState.role;
                if (role == 'Volunteer') {
                  return const ProfileScreen();
                } else if (role == 'Recipient') {
                  return const RecipientProfileScreen();
                } else {
                  return const Text('Unknown role');
                }
              }),
        ],
      ),
    ],
  );
}

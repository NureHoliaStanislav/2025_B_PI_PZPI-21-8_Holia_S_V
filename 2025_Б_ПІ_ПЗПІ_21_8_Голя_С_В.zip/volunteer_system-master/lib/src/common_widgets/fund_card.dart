import 'package:flutter/material.dart';
import 'package:volunteer_system/src/utils/api_config.dart';
import 'package:volunteer_system/src/models/fund_model.dart';
import 'package:volunteer_system/src/screens/fund_detail_screen.dart';
import 'package:volunteer_system/src/utils/monojar_script.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class FundCard extends StatefulWidget {
  final Fund fund;
  final VoidCallback onTap;

  const FundCard({
    super.key,
    required this.fund,
    required this.onTap,
  });

  @override
  State<FundCard> createState() => _FundCardState();
}

class _FundCardState extends State<FundCard> {
  double _percentageCollected = 0.0;

  @override
  void initState() {
    super.initState();
    _loadProgress();
  }

  Future<void> _loadProgress() async {
    final jarId = widget.fund.longJarId;
    try {
      final jarData = await getMonoJarData(jarId);
      setState(() {
        _percentageCollected = jarData.progressPercent / 100;
      });
    } catch (e) {
      print("Error fetching MonoJar data: $e");
      setState(() {
        _percentageCollected = 0.0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final fund = widget.fund;
    final fundName = fund.name;
    final volunteerName = fund.volunteer.name;
    final pictureUrl = fund.picture;
    final recipientName = fund.requirement.recipient.name.isNotEmpty
        ? fund.requirement.recipient.name
        : '—';
    final priority = fund.requirement.priority.name;
    final status = fund.status;

    // Localized status
    String localizedStatus;
    switch (status) {
      case 'Active':
        localizedStatus = AppLocalizations.of(context)!.statusActive;
        break;
      case 'Completed':
        localizedStatus = AppLocalizations.of(context)!.statusCompleted;
        break;
      case 'Cancelled':
        localizedStatus = AppLocalizations.of(context)!.statusCancelled;
        break;
      default:
        localizedStatus = AppLocalizations.of(context)!.statusUnknown;
    }

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => FundDetailScreen(fundId: fund.id),
          ),
        );
      },
      child: SizedBox(
        width: 280,
        height: 280,
        child: Card(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          elevation: 4,
          margin: const EdgeInsets.all(8),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Stack(
                  children: [
                    Container(
                      height: 130,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.grey.shade300,
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Stack(
                          children: [
                            if (pictureUrl != null && pictureUrl.isNotEmpty)
                              Image.network(
                                ApiConfig.baseUrl + pictureUrl,
                                fit: BoxFit.cover,
                                width: double.infinity,
                                height: double.infinity,
                                loadingBuilder:
                                    (context, child, loadingProgress) {
                                  if (loadingProgress == null) return child;
                                  return const Center(
                                      child: CircularProgressIndicator());
                                },
                                errorBuilder: (context, error, stackTrace) {
                                  return Center(
                                    child: Icon(
                                      Icons.broken_image,
                                      size: 50,
                                      color: Colors.grey.shade600,
                                    ),
                                  );
                                },
                              )
                            else
                              Center(
                                child: Icon(
                                  Icons.broken_image,
                                  size: 50,
                                  color: Colors.grey.shade600,
                                ),
                              ),

                            // Wave overlay
                            Positioned.fill(
                              child: CustomPaint(
                                painter: WavePainter(_percentageCollected),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      top: 8,
                      left: 8,
                      child: Row(
                        children: [
                          Container(
                            width: 10,
                            height: 10,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _getStatusColor(status),
                            ),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            localizedStatus,
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (priority == 'High')
                      const Positioned(
                        top: 8,
                        right: 8,
                        child: Text("🔥", style: TextStyle(fontSize: 24)),
                      ),
                    Positioned(
                      bottom: 8,
                      right: 8,
                      child: CircleAvatar(
                        backgroundColor: Colors.blueAccent,
                        radius: 14,
                        child: Text(
                          "${(_percentageCollected * 100).toInt()}%",
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  fundName,
                  style: Theme.of(context).textTheme.titleLarge,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Flexible(
                  child: Text(
                    '${AppLocalizations.of(context)!.volunteer}: $volunteerName',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey.shade700,
                        ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(height: 4),
                Flexible(
                  child: Text(
                    '${AppLocalizations.of(context)!.brigade}: $recipientName',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey.shade700,
                        ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Active':
        return Colors.green;
      case 'Completed':
        return Colors.blue;
      case 'Cancelled':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
}

class WavePainter extends CustomPainter {
  final double percentage;

  WavePainter(this.percentage);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.blue.withOpacity(0.5);
    final waveHeight = size.height * (1 - percentage);

    final path = Path();

    if (percentage >= 1.0) {
      path.addRect(Rect.fromLTRB(0, 0, size.width, size.height));
    } else {
      path
        ..moveTo(0, waveHeight)
        ..quadraticBezierTo(
          size.width * 0.25,
          waveHeight - 10,
          size.width * 0.5,
          waveHeight,
        )
        ..quadraticBezierTo(
          size.width * 0.75,
          waveHeight + 10,
          size.width,
          waveHeight,
        )
        ..lineTo(size.width, size.height)
        ..lineTo(0, size.height)
        ..close();
    }

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

import 'package:flutter/material.dart';
import 'package:volunteer_system/src/models/monojar_data_model.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class MonoJarProgressBar extends StatelessWidget {
  final MonoJarData jarData;

  const MonoJarProgressBar({super.key, required this.jarData});

  @override
  Widget build(BuildContext context) {
    final percent = jarData.progressPercent.clamp(0.0, 100.0);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppLocalizations.of(context)!.collected(
            (jarData.amount ~/ 100).toString(),
            (jarData.goal ~/ 100).toString(),
          ),
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: LinearProgressIndicator(
            value: percent / 100,
            minHeight: 12,
            backgroundColor: Colors.grey[300],
            valueColor: AlwaysStoppedAnimation<Color>(
              percent >= 100 ? Colors.green : Colors.blue,
            ),
          ),
        ),
        const SizedBox(height: 4),
        Align(
          alignment: Alignment.centerRight,
          child: Text('${percent.toStringAsFixed(1)}%',
              style: Theme.of(context).textTheme.labelSmall),
        ),
      ],
    );
  }
}

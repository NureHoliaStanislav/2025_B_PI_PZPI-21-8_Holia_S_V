import 'package:flutter/material.dart';
import 'package:volunteer_system/src/models/item_model.dart';
import 'package:volunteer_system/src/models/requirement_model.dart';
import 'package:volunteer_system/src/screens/requirement_detail_screen.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class RequirementCard extends StatelessWidget {
  final Requirement requirement;
  final List<Item> items; // лише перші 5 предметів
  final VoidCallback onTap;

  const RequirementCard({
    super.key,
    required this.requirement,
    required this.items,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isHighPriority = requirement.priority == Priority.High;
    final formattedDeadline = requirement.deadline != null
        ? "${requirement.deadline!.day.toString().padLeft(2, '0')}.${requirement.deadline!.month.toString().padLeft(2, '0')}.${requirement.deadline!.year}"
        : null;

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                RequirementDetailScreen(requirementId: requirement.id),
          ),
        );
      },
      child: Card(
        margin: const EdgeInsets.all(8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 3,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Назва + Пріоритет
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      requirement.name,
                      style: Theme.of(context).textTheme.titleLarge,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (isHighPriority)
                    const Text("🔥", style: TextStyle(fontSize: 24)),
                ],
              ),
              const SizedBox(height: 8),

              // Автор
              Text(
                "${AppLocalizations.of(context)!.createdBy}: ${requirement.recipient.name}",
                style: TextStyle(color: Colors.grey.shade700),
              ),
              const SizedBox(height: 12),

              // Список предметів
              ...items.take(5).map(
                    (item) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: Row(
                        children: [
                          const Icon(Icons.circle, size: 6),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              AppLocalizations.of(context)!
                                  .itemCountDisplay(item.name, item.count),
                              style: const TextStyle(fontSize: 14),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

              const SizedBox(height: 12),

              // Дедлайн, якщо є
              if (formattedDeadline != null)
                Row(
                  children: [
                    const Icon(Icons.access_time, size: 16),
                    const SizedBox(width: 6),
                    Text(
                        "${AppLocalizations.of(context)!.deadline}: $formattedDeadline"),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}

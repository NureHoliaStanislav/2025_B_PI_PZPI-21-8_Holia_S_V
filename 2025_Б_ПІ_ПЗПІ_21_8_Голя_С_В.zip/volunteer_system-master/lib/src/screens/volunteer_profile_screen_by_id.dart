import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:volunteer_system/src/utils/api_config.dart';
import 'package:volunteer_system/src/common_widgets/fund_card.dart';
import 'package:volunteer_system/src/models/fund_model.dart';
import 'package:volunteer_system/src/models/volunteer_model.dart';
import 'package:volunteer_system/src/services/volunteer_service.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class ProfileScreenById extends StatefulWidget {
  final String id;

  const ProfileScreenById({super.key, required this.id});

  @override
  State<ProfileScreenById> createState() => _ProfileScreenByIdState();
}

class _ProfileScreenByIdState extends State<ProfileScreenById> {
  Volunteer? _volunteer;
  List<Fund> _funds = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchProfileAndFunds();
  }

  Future<void> _fetchProfileAndFunds() async {
    try {
      final profile = await VolunteerService.getVolunteerProfileById(widget.id);
      if (profile != null) {
        final funds = await VolunteerService.fetchVolunteerFunds(profile.id);
        setState(() {
          _volunteer = profile;
          _funds = funds;
          _isLoading = false;
        });
      } else {
        setState(() => _isLoading = false);
      }
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context)!.volunteerProfile),
      ),
      backgroundColor: Colors.grey[200],
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _volunteer == null
              ? Center(
                  child: Text(AppLocalizations.of(context)!.profileLoadFailed))
              : SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildBanner(),
                      const SizedBox(height: 60),
                      _buildProfileCard(),
                      const SizedBox(height: 30),
                      if (_funds.isNotEmpty) _buildFundSlider(),
                    ],
                  ),
                ),
    );
  }

  Widget _buildBanner() {
    final imageUrl = _volunteer?.picture;
    final imageProvider = (imageUrl != null && imageUrl.isNotEmpty)
        ? NetworkImage(
            '${ApiConfig.baseUrl}$imageUrl?v=${DateTime.now().millisecondsSinceEpoch}')
        : const AssetImage("assets/default_avatar.png") as ImageProvider;

    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          height: 200,
          width: double.infinity,
          color: Colors.blue[700],
        ),
        Positioned(
          bottom: -50,
          left: MediaQuery.of(context).size.width / 2 - 50,
          child: CircleAvatar(
            radius: 50,
            backgroundColor: Colors.white,
            backgroundImage: imageProvider,
          ),
        ),
      ],
    );
  }

  Widget _buildProfileCard() {
    final v = _volunteer!;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            "${v.name} ${v.surname}",
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          _infoRow(Icons.email, v.email),
          const SizedBox(height: 12),
          _infoRow(Icons.phone, v.phone),
          const SizedBox(height: 12),
          _infoRow(Icons.cake,
              "${AppLocalizations.of(context)!.age}: ${v.age ?? AppLocalizations.of(context)!.unknown}"),
          const SizedBox(height: 12),
          _infoRow(Icons.work,
              "${AppLocalizations.of(context)!.specialization}: ${v.specific ?? AppLocalizations.of(context)!.notSpecified}"),
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String text) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 20, color: Colors.grey[700]),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            text,
            style: const TextStyle(fontSize: 16),
          ),
        ),
      ],
    );
  }

  Widget _buildFundSlider() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
          child: Text(
            AppLocalizations.of(context)!.funds,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ),
        SizedBox(
          height: 260,
          child: PageView.builder(
            controller: PageController(viewportFraction: 0.85),
            itemCount: _funds.length,
            itemBuilder: (context, index) {
              final fund = _funds[index];
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: FundCard(
                  fund: fund,
                  onTap: () => context.go('/fund/${fund.id}'),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:volunteer_system/src/utils/api_config.dart';
import 'package:volunteer_system/src/services/fund_service.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class UploadFundImageScreen extends StatefulWidget {
  final String fundId;

  const UploadFundImageScreen({super.key, required this.fundId});

  @override
  State<UploadFundImageScreen> createState() => _UploadFundImageScreenState();
}

class _UploadFundImageScreenState extends State<UploadFundImageScreen> {
  File? _imageFile;
  String? _uploadedImageUrl;

  Future<void> _pickImage() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image);
    if (result != null && result.files.single.path != null) {
      setState(() {
        _imageFile = File(result.files.single.path!);
      });
    }
  }

  Future<void> _uploadImage() async {
    if (_imageFile == null) return;

    final uploadedPath =
        await FundService.uploadFundImage(widget.fundId, _imageFile!);

    if (uploadedPath != null) {
      setState(() {
        _uploadedImageUrl = ApiConfig.baseUrl + uploadedPath;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(AppLocalizations.of(context)!.imageUploadSuccess)),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(AppLocalizations.of(context)!.imageUploadFailed)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final imageWidget = _imageFile != null
        ? Image.file(_imageFile!, height: 250, fit: BoxFit.cover)
        : _uploadedImageUrl != null
            ? Image.network(_uploadedImageUrl!, height: 250, fit: BoxFit.cover)
            : Container(
                height: 250,
                color: Colors.grey[200],
                child: const Center(child: Icon(Icons.image, size: 80)),
              );

    return Scaffold(
      appBar: AppBar(title: Text(AppLocalizations.of(context)!.uploadImage)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: imageWidget,
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _pickImage,
              icon: const Icon(Icons.photo_library),
              label: Text(AppLocalizations.of(context)!.pickImage),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: _uploadImage,
              icon: const Icon(Icons.cloud_upload),
              label: Text(AppLocalizations.of(context)!.upload),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(48),
              ),
            ),
            const Spacer(),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(AppLocalizations.of(context)!.finish),
            )
          ],
        ),
      ),
    );
  }
}

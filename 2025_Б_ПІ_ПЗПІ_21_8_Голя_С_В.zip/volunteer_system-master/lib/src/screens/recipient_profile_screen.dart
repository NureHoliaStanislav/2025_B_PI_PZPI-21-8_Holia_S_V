import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:volunteer_system/src/utils/api_config.dart';
import 'package:volunteer_system/src/common_widgets/requirement_card.dart';
import 'package:volunteer_system/src/models/recepient_model.dart';
import 'package:volunteer_system/src/models/requirement_model.dart';
import 'package:volunteer_system/src/screens/requirement_detail_screen.dart';
import 'package:volunteer_system/src/services/recipient_service.dart';
import 'package:volunteer_system/src/utils/auth_state.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class RecipientProfileScreen extends StatefulWidget {
  const RecipientProfileScreen({super.key});

  @override
  State<RecipientProfileScreen> createState() => _RecipientProfileScreenState();
}

class _RecipientProfileScreenState extends State<RecipientProfileScreen> {
  Recipient? _recipient;
  bool _isLoading = true;
  List<Requirement> _requirements = [];

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final profile = await RecipientService.getRecipientProfile();
    final requirements =
        await RecipientService.getRecipientRequirements(profile!.id);

    setState(() {
      _recipient = profile;
      _requirements = requirements;
      _isLoading = false;
    });
  }

  Future<void> _logout() async {
    await context.read<AuthState>().logout();
    if (!mounted) return;
    context.go('/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context)!.profile),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
            tooltip: AppLocalizations.of(context)!.logout,
          ),
        ],
      ),
      backgroundColor: Colors.grey[200],
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _recipient == null
              ? Center(
                  child: Text(AppLocalizations.of(context)!.profileLoadFailed))
              : SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildBanner(),
                      const SizedBox(height: 60),
                      _buildProfileCard(),
                      const SizedBox(height: 20),
                      _buildRequirementSlider(),
                    ],
                  ),
                ),
    );
  }

  Widget _buildBanner() {
    final imageUrl = _recipient?.profilePic;
    final imageProvider = (imageUrl != null && imageUrl.isNotEmpty)
        ? NetworkImage(ApiConfig.baseUrl + imageUrl)
        : const AssetImage("assets/default_avatar.png") as ImageProvider;

    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          height: 200,
          width: double.infinity,
          color: Colors.green[700],
        ),
        Positioned(
          bottom: -50,
          left: MediaQuery.of(context).size.width / 2 - 50,
          child: CircleAvatar(
            radius: 50,
            backgroundColor: Colors.white,
            backgroundImage: imageProvider,
          ),
        ),
      ],
    );
  }

  Widget _buildProfileCard() {
    final r = _recipient!;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            r.name,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          _infoRow(Icons.email, r.email),
        ],
      ),
    );
  }

  Widget _buildRequirementSlider() {
    if (_requirements.isEmpty) return const SizedBox();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
          child: Text(
            AppLocalizations.of(context)!.myRequirements,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ),
        SizedBox(
          height: 280,
          child: PageView.builder(
            controller: PageController(viewportFraction: 0.9),
            itemCount: _requirements.length,
            itemBuilder: (context, index) {
              final requirement = _requirements[index];

              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: RequirementCard(
                  requirement: requirement,
                  items: requirement.items.take(5).toList(),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => RequirementDetailScreen(
                            requirementId: requirement.id),
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _infoRow(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, size: 20, color: Colors.grey[700]),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            text,
            style: const TextStyle(fontSize: 16),
          ),
        ),
      ],
    );
  }
}

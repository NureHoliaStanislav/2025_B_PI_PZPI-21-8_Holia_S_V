import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:volunteer_system/src/utils/locale_state.dart';
import '../utils/auth_state.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool isLoading = false;

  void _login() async {
    setState(() => isLoading = true);

    final authState = context.read<AuthState>();

    final success = await authState.login(
      emailController.text.trim(),
      passwordController.text.trim(),
    );

    setState(() => isLoading = false);

    if (!mounted) return;

    if (!success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content:
                Text(AppLocalizations.of(context)!.invalidLoginCredentials)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppLocalizations.of(context)!.login)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                  labelText: AppLocalizations.of(context)!.email),
            ),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(
                  labelText: AppLocalizations.of(context)!.password),
              obscureText: true,
            ),
            // Add this widget where you want the user to pick a language
            DropdownButton<Locale>(
              value: context.watch<LocaleState>().locale ??
                  Localizations.localeOf(context),
              items: AppLocalizations.supportedLocales.map((locale) {
                final lang =
                    locale.languageCode == 'uk' ? 'Українська' : 'English';
                return DropdownMenuItem(
                  value: locale,
                  child: Text(lang),
                );
              }).toList(),
              onChanged: (locale) {
                if (locale != null) {
                  context.read<LocaleState>().setLocale(locale);
                }
              },
            ),
            const SizedBox(height: 20),
            isLoading
                ? const CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _login,
                    child: Text(AppLocalizations.of(context)!.login),
                  ),
          ],
        ),
      ),
    );
  }
}

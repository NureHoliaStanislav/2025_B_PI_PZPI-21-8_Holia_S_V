import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:volunteer_system/src/utils/api_config.dart';
import 'package:volunteer_system/src/common_widgets/monojar_progressbar.dart';
import 'package:volunteer_system/src/models/fund_model.dart';
import 'package:volunteer_system/src/models/monojar_data_model.dart';
import 'package:volunteer_system/src/screens/edit_fund_screen.dart';
import 'package:volunteer_system/src/screens/requirement_detail_screen.dart';
import 'package:volunteer_system/src/screens/volunteer_profile_screen_by_id.dart';
import 'package:volunteer_system/src/services/fund_service.dart';
import 'package:volunteer_system/src/utils/monojar_script.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class FundDetailScreen extends StatefulWidget {
  final String fundId;
  const FundDetailScreen({super.key, required this.fundId});

  @override
  State<FundDetailScreen> createState() => _FundDetailScreenState();
}

class _FundDetailScreenState extends State<FundDetailScreen> {
  Fund? _fund;
  MonoJarData? _jarData;
  bool _isLoading = true;
  String? _userId;
  bool? _reportExists;

  @override
  void initState() {
    super.initState();
    _loadUserIdAndFund().then((_) {
      _checkPdfReport();
    });
  }

  Future<void> _checkPdfReport() async {
    final url = Uri.parse('${ApiConfig.baseUrl}/uploads/${_fund?.id}.pdf');
    try {
      final response = await http.head(url);
      if (response.statusCode == 200) {
        setState(() {
          _reportExists = true;
        });
      } else {
        setState(() {
          _reportExists = false;
        });
      }
    } catch (e) {
      setState(() {
        _reportExists = false;
      });
    }
  }

  Future<void> _loadUserIdAndFund() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = prefs.getString('user_id');

    setState(() {
      _userId = userId;
    });

    await _loadFund();
  }

  Future<void> _loadFund() async {
    try {
      final fund = await FundService.fetchFundDetail(widget.fundId);
      MonoJarData? jarData;

      setState(() => _fund = fund);

      final jarId = fund?.longJarId;
      if (jarId != null && jarId.length == 32) {
        try {
          jarData = await getMonoJarData(jarId);
        } catch (e) {
          debugPrint("Помилка MonoJar: $e");
        }
      }

      setState(() {
        _jarData = jarData;
        _isLoading = false;
      });
    } catch (e) {
      debugPrint("Помилка завантаження збору: $e");
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    const double baseFontSize = 16;

    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context)!.fundDetails),
        actions: (_fund != null && _userId == _fund!.volunteer.id)
            ? [
                PopupMenuButton<String>(
                  onSelected: (value) async {
                    switch (value) {
                      case 'edit':
                        final result = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => EditFundScreen(fund: _fund!),
                          ),
                        );

                        if (result == true) {
                          final updatedFund =
                              await FundService.fetchFundDetail(_fund!.id);
                          if (updatedFund != null && mounted) {
                            setState(() => _fund = updatedFund);
                          }
                        }
                        break;

                      case 'deactivate':
                        final confirmed = await showDialog<bool>(
                          context: context,
                          builder: (context) => AlertDialog(
                            title: Text(AppLocalizations.of(context)!.confirm),
                            content: Text(AppLocalizations.of(context)!
                                .deactivateFundConfirm),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context, false),
                                child:
                                    Text(AppLocalizations.of(context)!.cancel),
                              ),
                              ElevatedButton(
                                onPressed: () => Navigator.pop(context, true),
                                child: Text(AppLocalizations.of(context)!
                                    .deactivateFundYes),
                              ),
                            ],
                          ),
                        );

                        if (confirmed == true) {
                          final success =
                              await FundService.deactivateFund(_fund!.id);
                          if (success) {
                            final updatedFund =
                                await FundService.fetchFundDetail(_fund!.id);
                            if (updatedFund != null && mounted) {
                              setState(() => _fund = updatedFund);
                            }
                          } else {
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                    content: Text(AppLocalizations.of(context)!
                                        .deactivateFundFailed)),
                              );
                            }
                          }
                        }
                        break;

                      case 'report':
                        debugPrint("Завантаження звіту");
                        final result = await FilePicker.platform.pickFiles(
                          type: FileType.custom,
                          allowedExtensions: ['pdf'],
                          withData: true,
                        );

                        if (result != null &&
                            result.files.single.bytes != null) {
                          final fileBytes = result.files.single.bytes!;
                          final fileName = result.files.single.name;

                          final success = await FundService.uploadReportPdf(
                              _fund!.id, fileBytes, fileName);
                          if (success && mounted) {
                            final updatedFund =
                                await FundService.fetchFundDetail(_fund!.id);
                            if (updatedFund != null) {
                              setState(() => _fund = updatedFund);
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                    content: Text(AppLocalizations.of(context)!
                                        .reportUploadSuccess)),
                              );
                            }
                          } else {
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                    content: Text(AppLocalizations.of(context)!
                                        .reportUploadFailed)),
                              );
                            }
                          }
                        }
                        break;
                    }
                  },
                  itemBuilder: (context) => [
                    PopupMenuItem(
                      value: 'edit',
                      child: Text(AppLocalizations.of(context)!.editFund),
                    ),
                    PopupMenuItem(
                      value: 'deactivate',
                      child: Text(AppLocalizations.of(context)!.deactivateFund),
                    ),
                    PopupMenuItem(
                      value: 'report',
                      child: Text(AppLocalizations.of(context)!.uploadReport),
                    ),
                  ],
                )
              ]
            : null,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _fund == null
              ? Center(
                  child: Text(AppLocalizations.of(context)!.fundLoadFailed))
              : SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // 🔳 Зображення
                      ClipRRect(
                        borderRadius: const BorderRadius.vertical(
                            bottom: Radius.circular(16)),
                        child: (_fund?.picture != null &&
                                _fund!.picture!.isNotEmpty)
                            ? Image.network(
                                ApiConfig.baseUrl + _fund!.picture!,
                                width: double.infinity,
                                height: 200,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) =>
                                    Container(
                                  width: double.infinity,
                                  height: 200,
                                  color: Colors.grey[300],
                                  child:
                                      const Icon(Icons.broken_image, size: 80),
                                ),
                              )
                            : Container(
                                width: double.infinity,
                                height: 200,
                                color: Colors.grey[300],
                                child: const Icon(Icons.broken_image, size: 80),
                              ),
                      ),

                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // 🟦 Назва
                            Text(
                              _fund!.name,
                              style: const TextStyle(
                                  fontSize: 22, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 12),

                            // 📃 Опис
                            Text(
                              _fund!.description ??
                                  AppLocalizations.of(context)!.noDescription,
                              style: const TextStyle(fontSize: baseFontSize),
                            ),
                            const SizedBox(height: 16),

                            // 📌 Статус
                            Chip(
                              label: Text(
                                  "${AppLocalizations.of(context)!.status}: ${_fund!.status}"),
                              backgroundColor: Colors.grey.shade200,
                            ),
                            const SizedBox(height: 16),

                            // 🔗 MonoJar Button
                            if (_fund!.monoJarUrl.isNotEmpty)
                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton.icon(
                                  onPressed: () async {
                                    final url = _fund!.monoJarUrl;
                                    if (!url.startsWith('http')) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                            content: Text(
                                                AppLocalizations.of(context)!
                                                    .invalidUrl)),
                                      );
                                      return;
                                    }
                                    final uri = Uri.parse(url);
                                    if (await canLaunchUrl(uri)) {
                                      await launchUrl(
                                        uri,
                                        mode: LaunchMode.externalApplication,
                                        webOnlyWindowName: '_blank',
                                      );
                                    } else {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                            content: Text(
                                                AppLocalizations.of(context)!
                                                    .openUrlFailed)),
                                      );
                                    }
                                  },
                                  icon: const Icon(Icons.open_in_new),
                                  label: Text(AppLocalizations.of(context)!
                                      .openMonobank),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.black,
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 20, vertical: 12),
                                    textStyle: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ),

                            const SizedBox(height: 24),

                            // 💰 Прогрес
                            if (_jarData != null) ...[
                              Text(
                                AppLocalizations.of(context)!.fundProgress,
                                style: const TextStyle(
                                    fontSize: baseFontSize + 2,
                                    fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 8),
                              MonoJarProgressBar(jarData: _jarData!),
                              const Divider(height: 32),
                            ],

                            // 📦 Вимога
                            Text(
                              AppLocalizations.of(context)!.requirement,
                              style: const TextStyle(
                                  fontSize: baseFontSize + 2,
                                  fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 6),
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        RequirementDetailScreen(
                                            requirementId:
                                                _fund!.requirement.id),
                                  ),
                                );
                              },
                              child: Text(
                                _fund!.requirement.name,
                                style: const TextStyle(
                                  fontSize: baseFontSize,
                                  color: Colors.blue,
                                  decoration: TextDecoration.underline,
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              "${AppLocalizations.of(context)!.deadline}: ${_fund!.requirement.deadline?.toString().split('T').first ?? '—'}",
                              style: const TextStyle(fontSize: baseFontSize),
                            ),
                            Text(
                              "${AppLocalizations.of(context)!.priority}: ${_fund!.requirement.priority.name}",
                              style: const TextStyle(fontSize: baseFontSize),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              AppLocalizations.of(context)!.items,
                              style: const TextStyle(
                                  fontSize: baseFontSize,
                                  fontWeight: FontWeight.w600),
                            ),
                            const SizedBox(height: 4),
                            ..._fund!.requirement.items
                                .where((item) => item.reservedBy == _fund!.id)
                                .map((item) => ListTile(
                                      dense: true,
                                      contentPadding: EdgeInsets.zero,
                                      title: Text(item.name),
                                      subtitle: Text(
                                          "${AppLocalizations.of(context)!.category}: ${item.category}"),
                                      trailing: Text("x${item.count}"),
                                    )),
                            const Divider(height: 32),

                            // 👤 Волонтер
                            Text(
                              AppLocalizations.of(context)!.volunteer,
                              style: const TextStyle(
                                  fontSize: baseFontSize + 2,
                                  fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 6),
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => ProfileScreenById(
                                        id: _fund!.volunteer.id),
                                  ),
                                );
                              },
                              child: Row(
                                children: [
                                  const Icon(Icons.person, size: 20),
                                  const SizedBox(width: 6),
                                  Text(
                                    "${_fund!.volunteer.name} ${_fund!.volunteer.surname}",
                                    style: const TextStyle(
                                      fontSize: baseFontSize,
                                      color: Colors.blue,
                                      decoration: TextDecoration.underline,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            if (_fund!.report != null) ...[
                              Text(
                                AppLocalizations.of(context)!.report,
                                style: const TextStyle(
                                    fontSize: baseFontSize + 2,
                                    fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                "${AppLocalizations.of(context)!.rating}: ${_fund!.report!.rating} / 5",
                                style: const TextStyle(fontSize: baseFontSize),
                              ),
                              Text(
                                "${AppLocalizations.of(context)!.finalConclusion}: ${_fund!.report!.finalConclusion}",
                                style: const TextStyle(fontSize: baseFontSize),
                              ),
                              const SizedBox(height: 8),
                              if (_reportExists == null)
                                const Center(child: CircularProgressIndicator())
                              else if (_reportExists!)
                                TextButton.icon(
                                  icon: const Icon(Icons.picture_as_pdf),
                                  label: Text(AppLocalizations.of(context)!
                                      .viewPdfReport),
                                  onPressed: () async {
                                    final url = Uri.parse(
                                        '${ApiConfig.baseUrl}/uploads/${_fund!.id}.pdf');
                                    if (await canLaunchUrl(url)) {
                                      await launchUrl(url,
                                          mode: LaunchMode.externalApplication);
                                    } else {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                            content: Text(
                                                AppLocalizations.of(context)!
                                                    .openPdfFailed)),
                                      );
                                    }
                                  },
                                )
                              else
                                Text(
                                  AppLocalizations.of(context)!
                                      .reportNotUploaded,
                                  style: const TextStyle(color: Colors.grey),
                                ),
                            ],
                            if (_userId == _fund!.requirement.recipient.id &&
                                _fund!.report == null) ...[
                              const SizedBox(height: 16),
                              ElevatedButton.icon(
                                onPressed: () async {
                                  final result =
                                      await showDialog<Map<String, dynamic>>(
                                    context: context,
                                    builder: (context) {
                                      int rating = 0;
                                      final TextEditingController
                                          conclusionController =
                                          TextEditingController();

                                      return AlertDialog(
                                        title: Text(
                                            AppLocalizations.of(context)!
                                                .leaveReview),
                                        content: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(AppLocalizations.of(context)!
                                                .ratingLabel),
                                            TextField(
                                              keyboardType:
                                                  TextInputType.number,
                                              onChanged: (value) {
                                                rating =
                                                    int.tryParse(value) ?? 0;
                                              },
                                              decoration: InputDecoration(
                                                  hintText: AppLocalizations.of(
                                                          context)!
                                                      .rating),
                                            ),
                                            const SizedBox(height: 12),
                                            Text(AppLocalizations.of(context)!
                                                .finalConclusion),
                                            TextField(
                                              controller: conclusionController,
                                              decoration: InputDecoration(
                                                  hintText: AppLocalizations.of(
                                                          context)!
                                                      .finalConclusion),
                                            ),
                                          ],
                                        ),
                                        actions: [
                                          TextButton(
                                            onPressed: () =>
                                                Navigator.pop(context),
                                            child: Text(
                                                AppLocalizations.of(context)!
                                                    .cancel),
                                          ),
                                          ElevatedButton(
                                            onPressed: () {
                                              Navigator.pop(context, {
                                                'rating': rating,
                                                'finalConclusion':
                                                    conclusionController.text,
                                              });
                                            },
                                            child: Text(
                                                AppLocalizations.of(context)!
                                                    .send),
                                          ),
                                        ],
                                      );
                                    },
                                  );

                                  if (result != null) {
                                    final success =
                                        await FundService.leaveFundReport(
                                      fundId: _fund!.id,
                                      rating: result['rating'] ?? 0,
                                      finalConclusion:
                                          result['finalConclusion'] ?? '',
                                    );

                                    if (success) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                            content: Text(
                                                AppLocalizations.of(context)!
                                                    .reviewAdded)),
                                      );

                                      final updatedFund =
                                          await FundService.fetchFundDetail(
                                              _fund!.id);
                                      if (updatedFund != null && mounted) {
                                        setState(() => _fund = updatedFund);
                                      }
                                    } else {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                            content: Text(
                                                AppLocalizations.of(context)!
                                                    .reviewAddFailed)),
                                      );
                                    }
                                  }
                                },
                                icon: const Icon(Icons.rate_review),
                                label: Text(
                                    AppLocalizations.of(context)!.leaveReview),
                              ),
                            ]
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }
}

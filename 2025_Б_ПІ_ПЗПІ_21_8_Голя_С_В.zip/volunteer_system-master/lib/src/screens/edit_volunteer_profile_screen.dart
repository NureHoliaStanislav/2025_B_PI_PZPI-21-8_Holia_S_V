import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:volunteer_system/src/utils/api_config.dart';
import 'package:volunteer_system/src/models/volunteer_model.dart';
import 'package:volunteer_system/src/services/volunteer_service.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class EditProfileScreen extends StatefulWidget {
  final Volunteer volunteer;

  const EditProfileScreen({super.key, required this.volunteer});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _nameController;
  late TextEditingController _surnameController;
  late TextEditingController _phoneController;
  late TextEditingController _specificController;
  late TextEditingController _ageController;
  late TextEditingController _profilePicController;

  bool _available = true;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.volunteer.name);
    _surnameController = TextEditingController(text: widget.volunteer.surname);
    _phoneController = TextEditingController(text: widget.volunteer.phone);
    _specificController =
        TextEditingController(text: widget.volunteer.specific ?? '');
    _ageController =
        TextEditingController(text: widget.volunteer.age?.toString() ?? '');
    _profilePicController =
        TextEditingController(text: widget.volunteer.picture ?? '');
    _available = widget.volunteer.available ?? true;
  }

  Future<void> _saveProfile() async {
    if (_formKey.currentState!.validate()) {
      final updated = widget.volunteer.copyWith(
        name: _nameController.text,
        surname: _surnameController.text,
        phone: _phoneController.text,
        specific: _specificController.text,
        picture: _profilePicController.text,
        available: _available,
        age: int.tryParse(_ageController.text),
      );
      await VolunteerService.updateProfile(updated);
      if (mounted) Navigator.pop(context);
    }
  }

  Future<void> _pickAndUploadImage() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image);
    if (result != null && result.files.single.path != null) {
      final file = File(result.files.single.path!);
      final filename = await VolunteerService.uploadProfileImage(file);

      if (filename != null) {
        setState(() {
          _profilePicController.text = filename;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text(AppLocalizations.of(context)!.imageUploadFailed)),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final imageUrl = _profilePicController.text.isNotEmpty
        ? '${ApiConfig.baseUrl}${_profilePicController.text}?v=${DateTime.now().millisecondsSinceEpoch}'
        : null;

    return Scaffold(
      appBar: AppBar(title: Text(AppLocalizations.of(context)!.editProfile)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Stack(
                  children: [
                    CircleAvatar(
                      radius: 60,
                      backgroundImage:
                          imageUrl != null ? NetworkImage(imageUrl) : null,
                      child: imageUrl == null
                          ? const Icon(Icons.person, size: 60)
                          : null,
                    ),
                    Positioned(
                      bottom: 0,
                      right: 4,
                      child: GestureDetector(
                        onTap: _pickAndUploadImage,
                        child: CircleAvatar(
                          radius: 20,
                          backgroundColor:
                              Theme.of(context).colorScheme.primary,
                          child: const Icon(Icons.edit, color: Colors.white),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                    labelText: AppLocalizations.of(context)!.firstName),
                validator: (value) => value!.isEmpty
                    ? AppLocalizations.of(context)!.enterFirstName
                    : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _surnameController,
                decoration: InputDecoration(
                    labelText: AppLocalizations.of(context)!.lastName),
                validator: (value) => value!.isEmpty
                    ? AppLocalizations.of(context)!.enterLastName
                    : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _phoneController,
                decoration: InputDecoration(
                    labelText: AppLocalizations.of(context)!.phone),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _specificController,
                decoration: InputDecoration(
                    labelText: AppLocalizations.of(context)!.specialization),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _ageController,
                decoration: InputDecoration(
                    labelText: AppLocalizations.of(context)!.age),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 12),
              SwitchListTile(
                value: _available,
                onChanged: (value) => setState(() => _available = value),
                title: Text(
                    AppLocalizations.of(context)!.availableForVolunteering),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _saveProfile,
                child: Text(AppLocalizations.of(context)!.save),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

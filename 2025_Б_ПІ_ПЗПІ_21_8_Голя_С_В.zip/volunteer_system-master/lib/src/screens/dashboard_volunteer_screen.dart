import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:volunteer_system/src/common_widgets/fund_card.dart';
import 'package:volunteer_system/src/common_widgets/requirement_card.dart';
import 'package:volunteer_system/src/services/dashboard_volunteer_service.dart';
import 'package:volunteer_system/src/models/fund_model.dart';
import 'package:volunteer_system/src/models/requirement_model.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class DashboardVolunteerPage extends StatefulWidget {
  const DashboardVolunteerPage({super.key});

  @override
  State<DashboardVolunteerPage> createState() => _DashboardVolunteerPageState();
}

class _DashboardVolunteerPageState extends State<DashboardVolunteerPage> {
  List<Fund> _funds = [];
  List<Requirement> _requirements = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    try {
      final data = await DashboardVolunteerService.fetchDashboardData(context);
      setState(() {
        _funds = List<Fund>.from(
          data['funds'].map((json) => Fund.fromJson(json)),
        );
        _requirements = List<Requirement>.from(
          data['requirements'].map((json) => Requirement.fromJson(json)),
        );
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('Dashboard error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Text(
                        AppLocalizations.of(context)!.myFunds,
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    ),
                    SizedBox(
                      height: 260,
                      child: PageView.builder(
                        controller: PageController(viewportFraction: 0.85),
                        itemCount: _funds.length,
                        itemBuilder: (context, index) {
                          final fund = _funds[index];
                          return Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: FundCard(
                              fund: fund,
                              onTap: () => context.go('/fund/${fund.id}'),
                            ),
                          );
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Text(
                        AppLocalizations.of(context)!.myRequirements,
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    ),
                    SizedBox(
                      height: 280,
                      child: PageView.builder(
                        controller: PageController(viewportFraction: 0.85),
                        itemCount: _requirements.length,
                        itemBuilder: (context, index) {
                          final req = _requirements[index];
                          return Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: RequirementCard(
                              requirement: req,
                              onTap: () => context.go('/requirement/${req.id}'),
                              items: req.items.take(5).toList(),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}

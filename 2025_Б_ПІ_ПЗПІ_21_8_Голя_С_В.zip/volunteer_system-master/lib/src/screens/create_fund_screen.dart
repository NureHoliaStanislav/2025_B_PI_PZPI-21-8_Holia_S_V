import 'package:flutter/material.dart';
import 'package:volunteer_system/src/models/requirement_model.dart';
import 'package:volunteer_system/src/services/fund_service.dart';
import 'upload_fund_image_screen.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class CreateFundScreen extends StatefulWidget {
  final Requirement requirement;

  const CreateFundScreen({super.key, required this.requirement});

  @override
  State<CreateFundScreen> createState() => _CreateFundScreenState();
}

class _CreateFundScreenState extends State<CreateFundScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _monoJarUrlController = TextEditingController();
  final _longJarIdController = TextEditingController();
  final Set<String> _selectedItemIds = {};

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) return;

    if (_selectedItemIds.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(AppLocalizations.of(context)!.selectAtLeastOneItem)),
      );
      return;
    }

    final fundData = {
      "name": _nameController.text,
      "description": _descriptionController.text,
      "mono_jar_url": _monoJarUrlController.text,
      "picture": "",
      "status": "Active",
      "long_jar_id": _longJarIdController.text,
      "report_id": "",
      //"requirement": widget.requirement.id,
      "items": _selectedItemIds.toList(),
    };

    final fundId = await FundService.createFund(fundData);

    if (fundId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(AppLocalizations.of(context)!.fundCreateFailed)),
      );
      return;
    }

    if (!mounted) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => UploadFundImageScreen(fundId: fundId),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final items = widget.requirement.items;

    return Scaffold(
      appBar: AppBar(title: Text(AppLocalizations.of(context)!.createFund)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              Text(
                AppLocalizations.of(context)!.selectItemsForFund,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              ...items.map((item) {
                final isReserved = item.reservedBy != null;
                return CheckboxListTile(
                  title: Text(
                    AppLocalizations.of(context)!
                        .itemWithCategory(item.name, item.count, item.category),
                    style:
                        isReserved ? const TextStyle(color: Colors.grey) : null,
                  ),
                  value: _selectedItemIds.contains(item.id),
                  onChanged: isReserved
                      ? null // Заборонити зміну
                      : (value) {
                          setState(() {
                            if (value == true) {
                              _selectedItemIds.add(item.id!);
                            } else {
                              _selectedItemIds.remove(item.id);
                            }
                          });
                        },
                  subtitle: isReserved
                      ? Text(
                          AppLocalizations.of(context)!.itemAlreadyReserved,
                          style:
                              const TextStyle(fontSize: 12, color: Colors.grey),
                        )
                      : null,
                  controlAffinity: ListTileControlAffinity.leading,
                );
              }).toList(),
              const SizedBox(height: 20),
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                    labelText: AppLocalizations.of(context)!.fundName),
                validator: (value) => value == null || value.isEmpty
                    ? AppLocalizations.of(context)!.enterFundName
                    : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(
                    labelText: AppLocalizations.of(context)!.description),
                maxLines: 3,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _monoJarUrlController,
                decoration: InputDecoration(
                    labelText: AppLocalizations.of(context)!.monoJarUrl),
                validator: (value) => value == null || value.isEmpty
                    ? AppLocalizations.of(context)!.enterMonoJarUrl
                    : null,
              ),
              const SizedBox(height: 12),
              Text(
                AppLocalizations.of(context)!.monoJarLongId,
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _longJarIdController,
                      validator: (value) => value == null || value.isEmpty
                          ? AppLocalizations.of(context)!.enterMonoJarId
                          : null,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.help_outline),
                    tooltip: AppLocalizations.of(context)!.howToGetLongId,
                    onPressed: _showLongJarIdHelpDialog,
                  ),
                ],
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: _submitForm,
                icon: const Icon(Icons.arrow_forward),
                label: Text(AppLocalizations.of(context)!.continueText),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(48),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showLongJarIdHelpDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(AppLocalizations.of(context)!.howToGetMonoJarLongId),
        content: Text(AppLocalizations.of(context)!.monoJarLongIdHelp),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(AppLocalizations.of(context)!.ok),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _monoJarUrlController.dispose();
    super.dispose();
  }
}

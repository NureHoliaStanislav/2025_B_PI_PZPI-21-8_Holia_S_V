import 'package:flutter/material.dart';
import 'package:volunteer_system/src/utils/api_config.dart';
import 'package:volunteer_system/src/screens/fund_detail_screen.dart';
import 'package:volunteer_system/src/screens/requirement_detail_screen.dart';
import 'package:volunteer_system/src/services/search_service.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class FundSearchPage extends StatefulWidget {
  const FundSearchPage({super.key});

  @override
  State<FundSearchPage> createState() => _FundSearchPageState();
}

class _FundSearchPageState extends State<FundSearchPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _fundController = TextEditingController();
  final TextEditingController _reqController = TextEditingController();

  List<dynamic> _fundResults = [];
  List<dynamic> _requirementResults = [];

  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  Future<void> _searchFunds(String query) async {
    if (query.isEmpty) return;

    setState(() => _isLoading = true);

    try {
      final results = await SearchService.searchFunds(query);
      setState(() => _fundResults = results);
    } catch (_) {
      setState(() => _fundResults = []);
    }

    setState(() => _isLoading = false);
  }

  Future<void> _searchRequirements(String query) async {
    if (query.isEmpty) return;

    setState(() => _isLoading = true);

    try {
      final results = await SearchService.searchRequirements(query);
      setState(() => _requirementResults = results);
    } catch (_) {
      setState(() => _requirementResults = []);
    }

    setState(() => _isLoading = false);
  }

  Widget _buildFundCard(dynamic fund) {
    final String? pictureUrl = fund['picture'];

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      child: ListTile(
        leading: pictureUrl != null && pictureUrl.isNotEmpty
            ? Image.network(
                ApiConfig.baseUrl + pictureUrl,
                width: 50,
                height: 50,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) =>
                    const Icon(Icons.image_not_supported),
              )
            : const Icon(Icons.image),
        title: Text(fund['name'] ?? AppLocalizations.of(context)!.noName),
        subtitle: Text(
          fund['description'] ?? AppLocalizations.of(context)!.noDescription,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        trailing: Text(fund['status'] ?? ''),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => FundDetailScreen(fundId: fund['id']),
            ),
          );
        },
      ),
    );
  }

  Widget _buildRequirementCard(dynamic requirement) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      child: ListTile(
        title:
            Text(requirement['name'] ?? AppLocalizations.of(context)!.noName),
        subtitle: Text(requirement['description'] ??
            AppLocalizations.of(context)!.noDescription),
        trailing: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(requirement['priority'] ??
                AppLocalizations.of(context)!.noPriority),
            Text(requirement['deadline'] ??
                AppLocalizations.of(context)!.noDeadline),
          ],
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  RequirementDetailScreen(requirementId: requirement['id']),
            ),
          );
        },
      ),
    );
  }

  Widget _buildTabContent({
    required TextEditingController controller,
    required VoidCallback onSearch,
    required List<dynamic> results,
    required Widget Function(dynamic) itemBuilder,
  }) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            controller: controller,
            decoration: InputDecoration(
              hintText: AppLocalizations.of(context)!.enterKeyword,
              suffixIcon: IconButton(
                icon: const Icon(Icons.search),
                onPressed: onSearch,
              ),
              border: const OutlineInputBorder(),
            ),
            onSubmitted: (_) => onSearch(),
          ),
        ),
        if (_isLoading)
          const Center(child: CircularProgressIndicator())
        else if (results.isEmpty)
          Padding(
            padding: const EdgeInsets.all(20),
            child: Text(AppLocalizations.of(context)!.nothingFound),
          )
        else
          Expanded(
            child: ListView.builder(
              itemCount: results.length,
              itemBuilder: (context, index) => itemBuilder(results[index]),
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(AppLocalizations.of(context)!.search),
          bottom: TabBar(
            controller: _tabController,
            tabs: [
              Tab(text: AppLocalizations.of(context)!.funds),
              Tab(text: AppLocalizations.of(context)!.requirements),
            ],
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          children: [
            _buildTabContent(
              controller: _fundController,
              onSearch: () => _searchFunds(_fundController.text),
              results: _fundResults,
              itemBuilder: _buildFundCard,
            ),
            _buildTabContent(
              controller: _reqController,
              onSearch: () => _searchRequirements(_reqController.text),
              results: _requirementResults,
              itemBuilder: _buildRequirementCard,
            ),
          ],
        ),
      ),
    );
  }
}

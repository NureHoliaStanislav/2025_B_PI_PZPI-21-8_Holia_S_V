import 'package:flutter/material.dart';
import 'package:volunteer_system/src/models/fund_model.dart';
import 'package:volunteer_system/src/services/fund_service.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class EditFundScreen extends StatefulWidget {
  final Fund fund;

  const EditFundScreen({super.key, required this.fund});

  @override
  State<EditFundScreen> createState() => _EditFundScreenState();
}

class _EditFundScreenState extends State<EditFundScreen> {
  late TextEditingController _nameController;
  late TextEditingController _descriptionController;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.fund.name);
    _descriptionController =
        TextEditingController(text: widget.fund.description);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _saveChanges() async {
    setState(() => _isSaving = true);
    final success = await FundService.updateFund(
      fundId: widget.fund.id,
      name: _nameController.text.trim(),
      description: _descriptionController.text.trim(),
    );
    setState(() => _isSaving = false);

    if (success && mounted) {
      Navigator.pop(context, true); // повертає true як ознаку успіху
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(AppLocalizations.of(context)!.fundEditFailed)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppLocalizations.of(context)!.editFund)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                  labelText: AppLocalizations.of(context)!.fundName),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _descriptionController,
              decoration: InputDecoration(
                  labelText: AppLocalizations.of(context)!.description),
              maxLines: 4,
            ),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: _isSaving ? null : _saveChanges,
              icon: const Icon(Icons.save),
              label: Text(AppLocalizations.of(context)!.save),
            ),
          ],
        ),
      ),
    );
  }
}

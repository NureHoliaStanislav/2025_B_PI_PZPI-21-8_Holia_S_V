import 'package:flutter/material.dart';
import 'package:volunteer_system/src/models/requirement_model.dart';
import 'package:volunteer_system/src/screens/fund_detail_screen.dart';
import 'package:volunteer_system/src/screens/create_fund_screen.dart';
import 'package:volunteer_system/src/services/requirement_service.dart';
import 'package:volunteer_system/src/services/auth_service.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class RequirementDetailScreen extends StatelessWidget {
  final String requirementId;

  const RequirementDetailScreen({super.key, required this.requirementId});

  @override
  Widget build(BuildContext context) {
    final requirementService = RequirementService();

    return FutureBuilder<Requirement>(
      future: requirementService.getRequirement(requirementId),
      builder: (context, snapshot) {
        final requirement = snapshot.data;

        return Scaffold(
          appBar: AppBar(
              title: Text(AppLocalizations.of(context)!.requirementDetails)),
          body: _buildBody(context, snapshot),
          floatingActionButton: FutureBuilder<bool>(
            future: AuthService.isVolunteer(),
            builder: (context, userSnapshot) {
              if (userSnapshot.connectionState != ConnectionState.done ||
                  !userSnapshot.hasData ||
                  !userSnapshot.data!) {
                return const SizedBox.shrink();
              }

              if (requirement == null) return const SizedBox.shrink();

              return FloatingActionButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          CreateFundScreen(requirement: requirement),
                    ),
                  );
                },
                tooltip: AppLocalizations.of(context)!.createFund,
                child: const Icon(Icons.add),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildBody(BuildContext context, AsyncSnapshot<Requirement> snapshot) {
    if (snapshot.connectionState == ConnectionState.waiting) {
      return const Center(child: CircularProgressIndicator());
    } else if (snapshot.hasError) {
      return Center(
          child: Text(
              '${AppLocalizations.of(context)!.error}: ${snapshot.error}'));
    } else if (!snapshot.hasData) {
      return Center(child: Text(AppLocalizations.of(context)!.noData));
    }

    final requirement = snapshot.data!;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(AppLocalizations.of(context)!.requirementName),
          _sectionContent(requirement.name),
          _sectionTitle(AppLocalizations.of(context)!.description),
          _sectionContent(requirement.description),
          _sectionTitle(AppLocalizations.of(context)!.priority),
          _sectionContent(requirement.priority.name),
          _sectionTitle(AppLocalizations.of(context)!.deadline),
          _sectionContent(requirement.deadline?.toLocal().toString() ?? '—'),
          _sectionTitle(AppLocalizations.of(context)!.items),
          if (requirement.items.isEmpty)
            _sectionContent(AppLocalizations.of(context)!.noItems)
          else
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: requirement.items.map((item) {
                return Container(
                  width: double.infinity,
                  padding:
                      const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.name,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      const SizedBox(height: 4),
                      Text('${item.count} × ${item.category}'),
                      if (item.reservedBy != null) ...[
                        const SizedBox(height: 8),
                        ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => FundDetailScreen(
                                  fundId: item.reservedBy!,
                                ),
                              ),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue.shade600,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                                vertical: 8, horizontal: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          child: Text(AppLocalizations.of(context)!.goToFund),
                        ),
                      ],
                    ],
                  ),
                );
              }).toList(),
            ),
          const SizedBox(height: 16),
          _sectionTitle(AppLocalizations.of(context)!.recipient),
          _sectionContent(requirement.recipient.name),
          _sectionTitle(AppLocalizations.of(context)!.funds),
          if (requirement.fund.isEmpty)
            _sectionContent(AppLocalizations.of(context)!.noFundsLinked)
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: requirement.fund.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final fund = requirement.fund[index];
                return InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            FundDetailScreen(fundId: fund['id']),
                      ),
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 12, horizontal: 16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: Colors.white,
                      border: Border.all(color: Colors.grey.shade300),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          fund['name'],
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                        const SizedBox(height: 4),
                        Text(
                            '${AppLocalizations.of(context)!.status}: ${fund['status']}'),
                      ],
                    ),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 4),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Colors.black87,
        ),
      ),
    );
  }

  Widget _sectionContent(String content) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        content,
        style: const TextStyle(fontSize: 16, color: Colors.black87),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:volunteer_system/src/common_widgets/fund_card.dart';
import 'package:volunteer_system/src/common_widgets/requirement_card.dart';
import 'package:volunteer_system/src/screens/create_requierement_screen.dart';
import 'package:volunteer_system/src/services/dashboard_recipient_service.dart';
import 'package:volunteer_system/src/models/fund_model.dart';
import 'package:volunteer_system/src/models/requirement_model.dart';
import 'package:volunteer_system/src/services/auth_service.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class DashboardRecipientPage extends StatefulWidget {
  const DashboardRecipientPage({super.key});

  @override
  State<DashboardRecipientPage> createState() => _DashboardRecipientPageState();
}

class _DashboardRecipientPageState extends State<DashboardRecipientPage> {
  List<Fund> _funds = [];
  List<Requirement> _requirements = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    try {
      final data = await DashboardRecipientService.fetchDashboardData(context);
      setState(() {
        _funds = List<Fund>.from(
          data['funds'].map((json) => Fund.fromJson(json)),
        );
        _requirements = List<Requirement>.from(
          data['requirements'].map((json) => Requirement.fromJson(json)),
        );
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('Recipient Dashboard error: $e');
    }
  }

  void _openCreateRequirementScreen() async {
    final token = await AuthService.getToken();
    if (!mounted) return;
    if (token == null) {
      debugPrint('Token is null, cannot open create requirement screen');
      return;
    }
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CreateRequirementScreen(token: token),
      ),
    );
    _loadDashboardData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Text(
                        AppLocalizations.of(context)!.myFunds,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 260,
                      child: PageView.builder(
                        controller: PageController(viewportFraction: 0.85),
                        itemCount: _funds.length,
                        itemBuilder: (context, index) {
                          final fund = _funds[index];
                          return Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: FundCard(
                              fund: fund,
                              onTap: () => context.go('/fund/${fund.id}'),
                            ),
                          );
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Text(
                        AppLocalizations.of(context)!.myRequirements,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 280,
                      child: PageView.builder(
                        controller: PageController(viewportFraction: 0.85),
                        itemCount: _requirements.length,
                        itemBuilder: (context, index) {
                          final req = _requirements[index];
                          return Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: RequirementCard(
                              requirement: req,
                              onTap: () => context.go('/requirement/${req.id}'),
                              items: req.items.take(5).toList(),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _openCreateRequirementScreen,
        child: const Icon(Icons.add),
      ),
    );
  }
}

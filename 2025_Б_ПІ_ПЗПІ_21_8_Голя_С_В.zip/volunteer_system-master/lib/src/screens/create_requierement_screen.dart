import 'package:flutter/material.dart';
import 'package:volunteer_system/src/models/category_enum.dart';
import 'package:volunteer_system/src/models/item_model.dart';
import '../services/requirement_service.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class CreateRequirementScreen extends StatefulWidget {
  final String token;

  const CreateRequirementScreen({super.key, required this.token});

  @override
  State<CreateRequirementScreen> createState() =>
      _CreateRequirementScreenState();
}

class _CreateRequirementScreenState extends State<CreateRequirementScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _descController = TextEditingController();
  DateTime? _deadline;
  String _priority = 'Default';

  final List<Item> _items = [];

  final _itemNameController = TextEditingController();
  final _itemCountController = TextEditingController();
  CategoryEnum _itemCategory = CategoryEnum.food;

  Future<void> _submit() async {
    if (_formKey.currentState!.validate()) {
      try {
        final requirementId = await RequirementService.createRequirement(
          token: widget.token,
          name: _nameController.text,
          description: _descController.text,
          priority: _priority,
          deadline: _deadline,
        );

        if (_items.isNotEmpty) {
          await RequirementService.addItemsToRequirement(
            token: widget.token,
            requirementId: requirementId,
            items: _items,
          );
        }

        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content:
                    Text(AppLocalizations.of(context)!.requirementCreated)),
          );
          Navigator.pop(context);
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${AppLocalizations.of(context)!.error}: $e')),
        );
      }
    }
  }

  void _addItem() {
    if (_itemNameController.text.isEmpty || _itemCountController.text.isEmpty)
      return;
    final item = Item(
      name: _itemNameController.text,
      count: int.tryParse(_itemCountController.text) ?? 0,
      category: _itemCategory.value,
    );
    setState(() {
      _items.add(item);
      _itemNameController.clear();
      _itemCountController.clear();
      _itemCategory = CategoryEnum.food;
    });
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descController.dispose();
    _itemNameController.dispose();
    _itemCountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          AppBar(title: Text(AppLocalizations.of(context)!.createRequirement)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                    labelText: AppLocalizations.of(context)!.requirementName),
                validator: (value) => value!.isEmpty
                    ? AppLocalizations.of(context)!.enterRequirementName
                    : null,
              ),
              TextFormField(
                controller: _descController,
                decoration: InputDecoration(
                    labelText: AppLocalizations.of(context)!.description),
              ),
              DropdownButtonFormField<String>(
                value: _priority,
                items: [
                  DropdownMenuItem(
                      value: 'Default',
                      child:
                          Text(AppLocalizations.of(context)!.priorityDefault)),
                  DropdownMenuItem(
                      value: 'High',
                      child: Text(AppLocalizations.of(context)!.priorityHigh)),
                ],
                onChanged: (val) => setState(() => _priority = val!),
                decoration: InputDecoration(
                    labelText: AppLocalizations.of(context)!.priority),
              ),
              const SizedBox(height: 12),
              ListTile(
                title: Text(
                  _deadline != null
                      ? '${AppLocalizations.of(context)!.deadline}: ${_deadline!.day.toString().padLeft(2, '0')}.${_deadline!.month.toString().padLeft(2, '0')}.${_deadline!.year}'
                      : AppLocalizations.of(context)!.selectDeadline,
                ),
                trailing: const Icon(Icons.calendar_today),
                onTap: () async {
                  final date = await showDatePicker(
                    context: context,
                    firstDate: DateTime.now(),
                    lastDate: DateTime(2100),
                    initialDate: DateTime.now(),
                  );
                  if (date != null) setState(() => _deadline = date);
                },
              ),
              const Divider(),
              Text(AppLocalizations.of(context)!.addItem,
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              TextField(
                controller: _itemNameController,
                decoration: InputDecoration(
                    labelText: AppLocalizations.of(context)!.itemName),
              ),
              TextField(
                controller: _itemCountController,
                decoration: InputDecoration(
                    labelText: AppLocalizations.of(context)!.itemCount),
                keyboardType: TextInputType.number,
              ),
              DropdownButtonFormField<CategoryEnum>(
                value: CategoryEnum.food,
                items: CategoryEnum.values.map((e) {
                  return DropdownMenuItem(
                    value: e,
                    child: Text(e.value),
                  );
                }).toList(),
                onChanged: (val) => setState(() {
                  if (val != null) _itemCategory = val;
                }),
                decoration: InputDecoration(
                    labelText: AppLocalizations.of(context)!.category),
              ),
              ElevatedButton.icon(
                onPressed: _addItem,
                icon: const Icon(Icons.add),
                label: Text(AppLocalizations.of(context)!.addItem),
              ),
              const Divider(),
              Text(AppLocalizations.of(context)!.items,
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              ..._items.map((item) => ListTile(
                    title: Text(AppLocalizations.of(context)!
                        .itemCountDisplay(item.name, item.count)),
                    subtitle: Text(
                        "${AppLocalizations.of(context)!.category}: ${item.category}"),
                  )),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submit,
                child: Text(AppLocalizations.of(context)!.createRequirement),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
